//Program to demonstrate Marker Interface
package com.tnsif.interfaces.markerinterfaces;

public interface Registrable {

}
