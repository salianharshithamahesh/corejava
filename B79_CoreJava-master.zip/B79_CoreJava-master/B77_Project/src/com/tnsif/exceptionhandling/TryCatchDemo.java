package com.tnsif.exceptionhandling;

public class TryCatchDemo {
public static void main(String[] args) {
		
		System.out.println("I am in main method"); 
		
		 TryCatchExample.performDivision(2,0);
		 TryCatchExample.performDivision(12,3);
	}
}

