package com.tnsif.multithreading;

public class RunnableDemo {

	public static void main(String[] args) {
		UsingRunnable obj=new UsingRunnable(1, 5, "Thread1 ");
		//Thread t=new Thread(obj);
		//t.start();
	}

}
